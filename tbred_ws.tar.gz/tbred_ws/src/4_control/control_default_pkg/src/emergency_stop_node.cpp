#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Bool.h>
#include <sstream>

bool stop_Var = false;
int temp = 0 ; 
float throttle_Var = 0.0;

void ReceivedStatusCallback(const std_msgs::Bool::ConstPtr& msg)
{
	
	if(msg->data == true){
	ROS_INFO("Status Received");
	}
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "emergency_stop_node");
	ros::NodeHandle n("~");

	ros::Publisher stop_pub = n.advertise<std_msgs::Bool>("emergency_stop", 1000);
	
// Subscribe to node states
	ros::Subscriber perceptionStatus_sub = n.subscribe("/perception_node/perceptionStatus", 1000, ReceivedStatusCallback);
	ros::Subscriber localisationStatus_sub = n.subscribe("/localisation_node/localisationStatus", 1000, ReceivedStatusCallback);
	ros::Subscriber planningStatus_sub = n.subscribe("/planning_node/planningStatus", 1000, ReceivedStatusCallback);
	ros::Subscriber controlStatus_sub = n.subscribe("/control_node/controlStatus", 1000, ReceivedStatusCallback);

// If any of the states == 0, shut down. NEEDS IMPLEMENTING
	
	ros::Rate loop_rate(10);
	while(ros::ok())
	{
		std_msgs::Bool stop_msg; 
		stop_msg.data = stop_Var; 
		stop_pub.publish(stop_msg);

		std::cin>> temp;
		if(temp == 0){
			stop_Var = false;
		}
		else{
			stop_Var = true;
		} 

		ros::spinOnce();
		loop_rate.sleep();
	
	}
}


