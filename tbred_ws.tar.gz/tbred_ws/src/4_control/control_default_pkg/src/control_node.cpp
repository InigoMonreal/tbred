#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Bool.h>
#include <sstream>


bool controlStatus_Var = false;
int temp = 0 ; 

void SteeringAngleCallback(const std_msgs::Float64::ConstPtr& msg)
{
	ROS_INFO("Steering Angle Recieved: [%f] \n", msg->data);
}

void BrakeCallback(const std_msgs::Float64::ConstPtr& msg)
{
	ROS_INFO("I heard: [%f] \n", msg->data);
}

void ThrottleCallback(const std_msgs::Float64::ConstPtr& msg)
{
	ROS_INFO("I heard: [%f] \n", msg->data);
}

void StopCallback(const std_msgs::Bool::ConstPtr& msg)
{
	if(msg->data == true){
	ROS_INFO("STOP!!!");
	}
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "control_node");
	ros::NodeHandle n("~");
	
	ros::Publisher controlStatus_pub = n.advertise<std_msgs::Bool>("controlStatus", 1000);

	ros::Subscriber steeringAngle_sub = n.subscribe("/planning_node/SteeringAngle", 1000, SteeringAngleCallback); 
	ros::Subscriber brake_sub = n.subscribe("/planning_node/Brake", 1000, BrakeCallback); 
	ros::Subscriber throttle_sub = n.subscribe("/planning_node/Throttle", 1000, ThrottleCallback);
	ros::Subscriber stop_sub = n.subscribe("/emergency_stop_node/emergency_stop", 1000, StopCallback);
	
	ros::Rate loop_rate(10);
    
    	while (ros::ok()) 
	{
		// controlStatus
		std_msgs::Bool controlStatus_msg; 
		controlStatus_msg.data = controlStatus_Var; 
		controlStatus_pub.publish(controlStatus_msg);

		std::cin>> temp;
		if(temp == 0){
			controlStatus_Var = false;
		}
		else{
			controlStatus_Var = true;
		} 

		ros::spinOnce();		
		loop_rate.sleep();
    	}
}


