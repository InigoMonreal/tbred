#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <sstream>

void SteeringAngleCallback(const std_msgs::Float64::ConstPtr& msg)
{
	ROS_INFO("Steering Angle Recieved: [%f] \n", msg->data);
}

void BrakeCallback(const std_msgs::Float64::ConstPtr& msg)
{
	ROS_INFO("I heard: [%f] \n", msg->data);
}

void ThrottleCallback(const std_msgs::Float64::ConstPtr& msg)
{
	ROS_INFO("I heard: [%f] \n", msg->data);
}


int main(int argc, char **argv)
{
	ros::init(argc, argv, "control_node");
	ros::NodeHandle n("~");
	ros::Subscriber Steering_Angle_Sub = n.subscribe("/planning_node/SteeringAngle", 1000, SteeringAngleCallback); 
	ros::Subscriber Brake_Sub = n.subscribe("/planning_node/Brake", 1000, BrakeCallback); 
	ros::Subscriber Throttle_Sub = n.subscribe("/planning_node/Throttle", 1000, ThrottleCallback);      
	
	ros::Rate loop_rate(10);
    
    	while (ros::ok()) 
	{
		ros::spinOnce();		
		loop_rate.sleep();
    	}

	

        
    
}


