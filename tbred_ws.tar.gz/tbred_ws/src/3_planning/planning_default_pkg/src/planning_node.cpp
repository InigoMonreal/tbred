#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <sstream>

float SteeringAngleVar = 0.0;
float BrakeVar = 0.0;
float ThrottleVar = 0.0;

void PosCallback(const std_msgs::Float64::ConstPtr& msg)
{
	ROS_INFO("Position Recieved: [%i] \n", msg->data); 
}



int main(int argc, char **argv)
{
	ros::init(argc, argv, "planning_node");
	ros::NodeHandle n("~");
	ros::Publisher plan_SteerAngle_Pub = n.advertise<std_msgs::Float64>("SteeringAngle", 1000);
	ros::Publisher plan_Brake_Pub = n.advertise<std_msgs::Float64>("Brake", 1000);
	ros::Publisher plan_Throttle_Pub = n.advertise<std_msgs::Float64>("Throttle", 1000);	
	
	ros::Subscriber pos_Sub = n.subscribe("/localisation_node/xyPosition", 1000, PosCallback); 

	ros::Rate loop_rate(10);
	while(ros::ok())
	{
		std_msgs::Float64 SteeringAngle_msg;
		SteeringAngleVar = 1.5;
		SteeringAngle_msg.data = SteeringAngleVar;
		plan_SteerAngle_Pub.publish(SteeringAngle_msg);

		std_msgs::Float64 Brake_msg; 
		BrakeVar = 2.5;
		Brake_msg.data = BrakeVar; 
		plan_Brake_Pub.publish(Brake_msg);

		std_msgs::Float64 Throttle_msg; 
		ThrottleVar = 3.5;
		Throttle_msg.data = ThrottleVar; 
		plan_Throttle_Pub.publish(Throttle_msg);

		ros::spinOnce();
		loop_rate.sleep();
	
	}
}


