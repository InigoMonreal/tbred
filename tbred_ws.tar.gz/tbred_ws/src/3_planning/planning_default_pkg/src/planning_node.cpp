#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <sstream>

bool planningStatus_Var = false;
int temp = 0 ; 
float steeringAngle_Var = 0.0;
float brake_Var = 0.0;
float throttle_Var = 0.0;

void PosCallback(const std_msgs::Float64::ConstPtr& msg)
{
	ROS_INFO("Position Recieved: [%i] \n", msg->data); 
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "planning_node");
	ros::NodeHandle n("~");
	
	//ros::Publisher planningStatus_pub = n.advertise<std_msgs::Bool>("planningStatus", 1000);
	ros::Publisher steeringAngle_pub = n.advertise<std_msgs::Float64>("SteeringAngle", 1000);
	ros::Publisher brake_pub = n.advertise<std_msgs::Float64>("Brake", 1000);
	ros::Publisher throttle_pub = n.advertise<std_msgs::Float64>("Throttle", 1000);	
	
	ros::Subscriber position_sub = n.subscribe("/localisation_node/xyPosition", 1000, PosCallback);
	//ros::Subscriber stop_sub = n.subscribe("/emergency_stop_node/emergency_stop", 1000, StopCallback); 

	ros::Rate loop_rate(10);
	while(ros::ok())
	{
		std_msgs::Float64 steeringAngle_msg;
		steeringAngle_Var = 1.5;
		steeringAngle_msg.data = steeringAngle_Var;
		steeringAngle_pub.publish(steeringAngle_msg);

		std_msgs::Float64 brake_msg; 
		brake_Var = 2.5;
		brake_msg.data = brake_Var; 
		brake_pub.publish(brake_msg);

		std_msgs::Float64 throttle_msg; 
		throttle_Var = 3.5;
		throttle_msg.data = throttle_Var; 
		throttle_pub.publish(throttle_msg);

		/*// planningStatus
		std_msgs::Bool planningStatus_msg; 
		planningStatus_msg.data = planningStatus_Var; 
		planningStatus_pub.publish(planningStatus_msg);

		std::cin>> temp;
		if(temp == 0){
			planningStatus_Var = false;
		}
		else{
			planningStatus_Var = true;
		} 
		*/
		ros::spinOnce();
		loop_rate.sleep();
	
	}
}


