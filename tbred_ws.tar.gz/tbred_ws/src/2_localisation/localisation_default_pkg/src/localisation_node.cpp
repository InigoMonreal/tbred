#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float64.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Int16.h>
#include <std_msgs/ColorRGBA.h>
#include <sensor_msgs/PointCloud.h>
#include <sstream>


float x_pos = 0.0;
float y_pos = 0.0;
float theta_pos = 0.0;

void ConeCountCallback(const std_msgs::Int16::ConstPtr& msg)
{
	ROS_INFO("Position Recieved: [%f] \n", msg->data); 
}

void ConeCoordsCallback(const sensor_msgs::PointCloud::ConstPtr& msg)
{
	ROS_INFO("Position Recieved: [%f] \n", msg->header); 
}

void ConeColorCallback(const std_msgs::ColorRGBA::ConstPtr& msg)
{
	ROS_INFO("Position Recieved: [%f] \n", msg->r); 
}






int main(int argc, char **argv)
{
	ros::init(argc, argv, "localisation_node");
	ros::NodeHandle n("~");
	ros::Publisher Odom_Pub = n.advertise<nav_msgs::Odometry>("Odometry", 1000);	
	ros::Publisher Position_Pub = n.advertise<std_msgs::Float64>("xyPosition", 1000);

	ros::Subscriber cone_count_Sub = n.subscribe("/perception_node/cone_count", 1000, ConeCountCallback);
	ros::Subscriber cone_coords_Sub = n.subscribe("/perception_node/cone_coords", 1000, ConeCoordsCallback);
	ros::Subscriber cone_color_Sub = n.subscribe("/perception_node/cone_color", 1000, ConeColorCallback);

	ros::Rate loop_rate(10);
	while(ros::ok())
	{
		std_msgs::Float64 xyPos_msg;
		x_pos = 5.5;
		xyPos_msg.data = x_pos;
		Position_Pub.publish(xyPos_msg);

		ros::spinOnce();
		loop_rate.sleep();
	
	}
}

