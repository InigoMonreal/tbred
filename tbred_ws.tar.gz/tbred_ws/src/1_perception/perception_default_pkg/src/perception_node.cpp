#include <ros/ros.h>
#include "std_msgs/String.h"
#include <std_msgs/Int16.h>
#include <std_msgs/ColorRGBA.h>
#include <sensor_msgs/PointCloud.h>
#include <sstream>


int main(int argc, char **argv) {
    ros::init(argc, argv, "perception_node");
    ros::NodeHandle n("~");

    ros::Publisher cone_count_pub = n.advertise<std_msgs::Int16>("cone_count", 1000);
    ros::Publisher cone_color_pub = n.advertise<std_msgs::ColorRGBA>("cone_color", 1000);
    ros::Publisher cone_coords_pub = n.advertise<sensor_msgs::PointCloud>("cone_coords", 1000);
    ros::Rate loop_rate(10);
	
    int count = 0;
    unsigned int num_points = 100;
    while (ros::ok()) {
	
	// initialise messages
        std_msgs::Int16 count_msg;
        std_msgs::ColorRGBA color_msg;
	sensor_msgs::PointCloud coords_msg;

	//dummy data for coords_msg
        coords_msg.header.stamp = ros::Time::now();
	coords_msg.header.frame_id = "sensor_frame";
	coords_msg.points.resize(num_points);
	coords_msg.channels.resize(1);
        coords_msg.channels[0].name = "intensities";
        coords_msg.channels[0].values.resize(num_points);

       for(unsigned int i = 0; i < num_points; ++i){
         coords_msg.points[i].x = 1 + count;
         coords_msg.points[i].y = 2 + count;
         coords_msg.points[i].z = 3 + count;
         coords_msg.channels[0].values[i] = 100 + count;
       }
	//_________________________________________

	//dummy data for color and cone count
	count_msg.data = 69;
	color_msg.r = 255.0;
	color_msg.g = 255.0;
	color_msg.b = 255.0;
	color_msg.a = 128.0;
	////_______________________________________________________
	
	
	//publish messages to topics
	cone_count_pub.publish(count_msg);
	cone_color_pub.publish(color_msg);
	cone_coords_pub.publish(coords_msg);

        ros::spinOnce();
	++count;
        loop_rate.sleep();

    }
}

