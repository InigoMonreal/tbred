#include <ros/ros.h>
#include "std_msgs/String.h"
#include <std_msgs/Int16.h>
#include <std_msgs/Bool.h>
#include <std_msgs/ColorRGBA.h>
#include <sensor_msgs/PointCloud.h>
#include <sstream>

bool perceptionStatus_Var = false; 
int temp = 0 ;

int main(int argc, char **argv) {
   	ros::init(argc, argv, "camera_1_node");
	ros::NodeHandle n("~");

	ros::Publisher perceptionStatus_pub = n.advertise<std_msgs::Bool>("perceptionStatus", 1000);
	ros::Publisher coneCount_pub = n.advertise<std_msgs::Int16>("coneCount", 1000);
	ros::Publisher coneColor_pub = n.advertise<std_msgs::ColorRGBA>("coneColor", 1000);
	ros::Publisher coneCoords_pub = n.advertise<sensor_msgs::PointCloud>("coneCoords", 1000);
	//ros::Publisher stop_pub = n.advertise<std_msgs::Bool>("/emergency_stop_node/emergency_stop", 1000);
	//ros::Subscriber stop_Sub = n.subscribe("/emergency_stop_node/emergency_stop", 1000, StopCallback);
    
	ros::Rate loop_rate(10);
	
int count = 0;
unsigned int num_points = 100;
while (ros::ok()) {
	
	// initialise messages
        std_msgs::Int16 count_msg;
        std_msgs::ColorRGBA color_msg;
	sensor_msgs::PointCloud coords_msg;

	//dummy data for coords_msg
        coords_msg.header.stamp = ros::Time::now();
	coords_msg.header.frame_id = "sensor_frame";
	coords_msg.points.resize(num_points);
	coords_msg.channels.resize(1);
        coords_msg.channels[0].name = "intensities";
        coords_msg.channels[0].values.resize(num_points);

       for(unsigned int i = 0; i < num_points; ++i){
         coords_msg.points[i].x = 1 + count;
         coords_msg.points[i].y = 2 + count;
         coords_msg.points[i].z = 3 + count;
         coords_msg.channels[0].values[i] = 100 + count;
       }
	//_________________________________________

	//dummy data for color and cone count
	count_msg.data = 69;
	color_msg.r = 255.0;
	color_msg.g = 255.0;
	color_msg.b = 255.0;
	color_msg.a = 128.0;
	////_______________________________________________________
	
	
	//publish messages to topics
	coneCount_pub.publish(count_msg);
	coneColor_pub.publish(color_msg);
	coneCoords_pub.publish(coords_msg);
	
	/*std_msgs::Bool stop_msg; 	
	stop_msg.data = stop_Var; 
	stop_pub.publish(stop_msg);
	if(coords_msg.points[1].x < 5000){
		stop_Var = true;
	}
	*/
        ros::spinOnce();
	++count;
        loop_rate.sleep();

		// perceptionStatus
		std_msgs::Bool perceptionStatus_msg; 
		perceptionStatus_msg.data = perceptionStatus_Var; 
		perceptionStatus_pub.publish(perceptionStatus_msg);

		std::cin>> temp;
		if(temp == 0){
			perceptionStatus_Var = false;
		}
		else{
			perceptionStatus_Var = true;
		} 


    }
}

